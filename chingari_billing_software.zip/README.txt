CHINGARI BILLING - Free starter
Open index.html in a browser. Data is stored locally in that browser.
Features: products, stock, customers, billing, paid/due, sales history, low-stock alert, printable invoice.
For a public URL, upload index.html to a static host such as GitHub Pages or Vercel.
